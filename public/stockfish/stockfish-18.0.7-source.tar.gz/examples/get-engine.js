"use strict";

var fs = require("fs");
var p = require("path");

var node_modules = p.join(__dirname, "node_modules");
var basedir = p.join(node_modules, "stockfish");
var bindir = p.join(basedir, "bin");
var stockfishVersion;

function hasEngines()
{
    var moduleConfig;
    var installedModuleConfig;
    try {
        installedModuleConfig = require(p.join(basedir, "package.json"));
        moduleConfig = require(p.join(__dirname, "..", "package.json"));
    } catch (e) {}
    
    if (moduleConfig) {
        stockfishVersion = moduleConfig.version;
    }
    /// Confirm package version.
    if (!installedModuleConfig || !moduleConfig || moduleConfig.version !== installedModuleConfig.version) {
        return false;
    }
    /// Make sure the engine files are actually there.
    return fs.existsSync(p.join(bindir, "stockfish.js")) && fs.existsSync(p.join(bindir, "stockfish.wasm"));

}

if (!hasEngines()) {
    /// Ensure node_modules exists before installing to get the files into the right place.
    try {
        fs.mkdirSync(node_modules);
    } catch (e) {}
    console.log("-----------")
    console.log("installing", (stockfishVersion || "latest"))
    console.log("-----------")
    require("child_process").execFileSync("npm", ["i", "--force", "--no-package-lock", "stockfish@" + (stockfishVersion || "latest")], {cwd: __dirname});
    if (!hasEngines()) {
        console.error("Could not find stockfish engine. Please run \"npm install\" first.");
        process.exit(1);
    }
}
